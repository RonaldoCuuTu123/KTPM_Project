import CashBook from './components/CashBook';
import './App.css'

function App() {
  return <CashBook />;
}

export default App
